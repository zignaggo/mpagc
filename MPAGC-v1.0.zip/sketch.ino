#include <WiFi.h>
#include <HTTPClient.h>
#include <UrlEncode.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>


// --- DISPLAY OLED ---
#define SCREEN_WIDTH 128 
#define SCREEN_HEIGHT 64 
#define OLED_RESET -1 
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// --- PINOS ---
#define PIN_LED 2
#define PIN_GLP 34
#define PIN_BUZZER 16

// --- PARÂMETROS ---
#define GAS_THRESHOLD 3800

// --- WIFI DEFINITIONS ---
#define WIFI_SSID "Wokwi-GUEST"
#define WIFI_PASSWORD ""
#define WIFI_CHANNEL 6

// --- WHATSAPP ---
#define PHONE "558299140037"
#define KEY_CALLMEBOT "2542668"

void setup() {
  Serial.begin(115200);

  pinMode(PIN_LED, OUTPUT);
  pinMode(PIN_BUZZER, OUTPUT);

  Wire.begin(); 

  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("Falha ao inicializar o display OLED. Verifique o I2C."));
  }
  
  display.display();
  delay(2000); 

  connect_wifi();
}


void loop() {
  scan_glp();
  delay(2000);
}


void turn_on() {
  digitalWrite(PIN_LED, HIGH);
}

void turn_of() {
  digitalWrite(PIN_LED, LOW);
}

void connect_wifi() {
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD, WIFI_CHANNEL);
  Serial.print("Connecting to WiFi ");
  Serial.print(WIFI_SSID);

  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println(" Connected!");
    Serial.print("IP address: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println(" Falha na Conexão WiFi.");
  }
}

void send_message(String message) {
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;

    String encodedMessage = urlEncode(message);
    String url = String("https://api.callmebot.com/whatsapp.php?phone=") + PHONE + "&text=" + encodedMessage + "&apikey=" + KEY_CALLMEBOT;

    http.begin(url);
    int httpCode = http.GET();
    if (httpCode >= 200 && httpCode <= 300) {
      Serial.printf("Mensagem enviada! Código HTTP: %d\n", httpCode);
    } else {
      Serial.printf("Erro ao enviar mensagem: %d\n", httpCode);
    }
    http.end();
  } else {
    Serial.println("WiFi não conectado. Mensagem não enviada.");
  }
}


void scan_glp() {
  int gas_value = analogRead(PIN_GLP);
  bool alert_status = false;

  Serial.print("Gas Sensor Value (Analog): ");
  Serial.println(gas_value);

  if (gas_value >= GAS_THRESHOLD) {
    alert_status = true;
    turn_on();
    Serial.println("Danger! Gas leak Detected! (HIGH LEVEL)");
    tone(PIN_BUZZER, 1000, 500); 
    
  }
  else {
    turn_of();
    Serial.println("Environment safe (LOW LEVEL)");
    noTone(PIN_BUZZER);
  }

  update_display(gas_value, alert_status);
}

void update_display(int gas_value, bool alert_status) {
  display.clearDisplay();
  display.setTextColor(WHITE);

  // Título
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.println("Detector de Gas GLP");
  display.drawFastHLine(0, 10, SCREEN_WIDTH, WHITE);

  // Status Principal
  display.setTextSize(2); 
  display.setCursor(0, 20);
  if (alert_status) {
    display.setTextColor(BLACK, WHITE); // Inverte cores para ALERTA
    display.println("ALERTA!");
    display.setTextColor(WHITE);
  } else {
    display.println("Seguro");
  }

  // Valor Analógico
  display.setTextSize(1);
  display.setCursor(0, 45);
  display.print("Leitura (ADC): ");
  display.print(gas_value);
  
  // Limiar
  display.setCursor(0, 55);
  display.print("Limiar: >");
  display.print(GAS_THRESHOLD);

  // Exibe tudo
  display.display();
}